Collection notebook and code related to LLM and Prompt
