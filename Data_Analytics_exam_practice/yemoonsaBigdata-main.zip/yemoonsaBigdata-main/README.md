# yemoonsaBigdata
2023 빅데이터분석기사 실기 (예문사) 예제 모음

- ./datasets/Part2/ : 파트2의 파이썬 실습 데이터 셋
- ./datasets/Part3/ : 파트3의 파이썬 실습 데이터 셋
- ./datasets/Supplement/ : 부록의 파이썬 실습 데이터 셋
- ./src/ : 예제 파이썬 노트북 파일
- ./res/ : 결과물, 정답 파일
